package com.phonemod.network.packet;

import com.phonemod.data.PhoneMessage;
import com.phonemod.data.PhoneSavedData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SendMessagePacket {
    private final String toPlayer;
    private final String text;

    public SendMessagePacket(String toPlayer, String text) {
        this.toPlayer = toPlayer;
        this.text = text;
    }

    public static void encode(SendMessagePacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.toPlayer);
        buf.writeUtf(msg.text);
    }

    public static SendMessagePacket decode(FriendlyByteBuf buf) {
        return new SendMessagePacket(buf.readUtf(), buf.readUtf());
    }

    public static void handle(SendMessagePacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sender = ctx.get().getSender();
            if (sender == null) return;
            ServerPlayer target = sender.getServer().getPlayerList().getPlayerByName(msg.toPlayer);
            if (target == null) {
                sender.sendSystemMessage(Component.literal("§c[Telefon] Jucatorul nu este online."));
                return;
            }
            PhoneSavedData data = PhoneSavedData.get(sender.serverLevel());
            data.addMessage(target.getUUID(), new PhoneMessage(sender.getUUID(), sender.getGameProfile().getName(), msg.text, System.currentTimeMillis()));
            target.sendSystemMessage(Component.literal("§b[Telefon] Ai un mesaj nou de la " + sender.getGameProfile().getName()));
        });
        ctx.get().setPacketHandled(true);
    }
}
