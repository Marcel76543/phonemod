package com.phonemod.network;

import com.phonemod.PhoneMod;
import com.phonemod.network.packet.AddListingPacket;
import com.phonemod.network.packet.BuyListingPacket;
import com.phonemod.network.packet.RequestDataPacket;
import com.phonemod.network.packet.SendMessagePacket;
import com.phonemod.network.packet.SyncDataPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class NetworkHandler {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(PhoneMod.MODID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int id = 0;
    private static int nextId() {
        return id++;
    }

    public static void register() {
        CHANNEL.registerMessage(nextId(), RequestDataPacket.class, RequestDataPacket::encode, RequestDataPacket::decode, RequestDataPacket::handle);
        CHANNEL.registerMessage(nextId(), SyncDataPacket.class, SyncDataPacket::encode, SyncDataPacket::decode, SyncDataPacket::handle);
        CHANNEL.registerMessage(nextId(), SendMessagePacket.class, SendMessagePacket::encode, SendMessagePacket::decode, SendMessagePacket::handle);
        CHANNEL.registerMessage(nextId(), AddListingPacket.class, AddListingPacket::encode, AddListingPacket::decode, AddListingPacket::handle);
        CHANNEL.registerMessage(nextId(), BuyListingPacket.class, BuyListingPacket::encode, BuyListingPacket::decode, BuyListingPacket::handle);
    }
}
