package com.phonemod.network.packet;

import com.phonemod.data.OlxListing;
import com.phonemod.data.PhoneSavedData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AddListingPacket {
    private final int price;
    private final String description;

    public AddListingPacket(int price, String description) {
        this.price = price;
        this.description = description;
    }

    public static void encode(AddListingPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.price);
        buf.writeUtf(msg.description);
    }

    public static AddListingPacket decode(FriendlyByteBuf buf) {
        return new AddListingPacket(buf.readInt(), buf.readUtf());
    }

    public static void handle(AddListingPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            ItemStack held = player.getMainHandItem();
            if (held.isEmpty()) {
                player.sendSystemMessage(Component.literal("§c[OLX] Trebuie sa tii un item in mana pentru a-l posta."));
                return;
            }
            if (msg.price <= 0) {
                player.sendSystemMessage(Component.literal("§c[OLX] Pret invalid."));
                return;
            }
            ItemStack toSell = held.copy();
            held.shrink(held.getCount());
            PhoneSavedData data = PhoneSavedData.get(player.serverLevel());
            data.addListing(new OlxListing(0, player.getUUID(), player.getGameProfile().getName(), toSell, msg.price, msg.description));
            player.sendSystemMessage(Component.literal("§a[OLX] Anuntul a fost publicat!"));
        });
        ctx.get().setPacketHandled(true);
    }
}
