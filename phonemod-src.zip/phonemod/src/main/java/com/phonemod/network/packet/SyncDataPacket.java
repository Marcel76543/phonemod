package com.phonemod.network.packet;

import com.phonemod.client.ClientDataCache;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class SyncDataPacket {
    private final CompoundTag tag;

    public SyncDataPacket(CompoundTag tag) {
        this.tag = tag;
    }

    public static void encode(SyncDataPacket msg, FriendlyByteBuf buf) {
        buf.writeNbt(msg.tag);
    }

    public static SyncDataPacket decode(FriendlyByteBuf buf) {
        return new SyncDataPacket(buf.readNbt());
    }

    public static void handle(SyncDataPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientDataCache.receive(msg.tag)));
        ctx.get().setPacketHandled(true);
    }
}
