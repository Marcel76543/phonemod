package com.phonemod.network.packet;

import com.phonemod.data.OlxListing;
import com.phonemod.data.PhoneSavedData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class BuyListingPacket {
    private final int listingId;

    public BuyListingPacket(int listingId) {
        this.listingId = listingId;
    }

    public static void encode(BuyListingPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.listingId);
    }

    public static BuyListingPacket decode(FriendlyByteBuf buf) {
        return new BuyListingPacket(buf.readInt());
    }

    public static void handle(BuyListingPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer buyer = ctx.get().getSender();
            if (buyer == null) return;
            PhoneSavedData data = PhoneSavedData.get(buyer.serverLevel());

            OlxListing listing = null;
            for (OlxListing l : data.getListings()) {
                if (l.id == msg.listingId) {
                    listing = l;
                    break;
                }
            }
            if (listing == null) {
                buyer.sendSystemMessage(Component.literal("§c[OLX] Anuntul nu mai exista."));
                return;
            }
            if (listing.sellerUUID.equals(buyer.getUUID())) {
                buyer.sendSystemMessage(Component.literal("§c[OLX] Nu poti cumpara propriul anunt."));
                return;
            }

            int emeraldsHave = 0;
            for (ItemStack stack : buyer.getInventory().items) {
                if (stack.is(Items.EMERALD)) emeraldsHave += stack.getCount();
            }
            if (emeraldsHave < listing.price) {
                buyer.sendSystemMessage(Component.literal("§c[OLX] Nu ai suficiente smaralde. Ai nevoie de " + listing.price + "."));
                return;
            }

            int toRemove = listing.price;
            for (ItemStack stack : buyer.getInventory().items) {
                if (toRemove <= 0) break;
                if (stack.is(Items.EMERALD)) {
                    int take = Math.min(toRemove, stack.getCount());
                    stack.shrink(take);
                    toRemove -= take;
                }
            }

            if (!buyer.getInventory().add(listing.stack.copy())) {
                buyer.drop(listing.stack.copy(), false);
            }

            ServerPlayer seller = buyer.getServer().getPlayerList().getPlayer(listing.sellerUUID);
            if (seller != null) {
                ItemStack payment = new ItemStack(Items.EMERALD, listing.price);
                if (!seller.getInventory().add(payment)) seller.drop(payment, false);
                seller.sendSystemMessage(Component.literal("§a[OLX] " + buyer.getGameProfile().getName() + " a cumparat anuntul tau!"));
            }

            data.removeListing(listing.id);
            buyer.sendSystemMessage(Component.literal("§a[OLX] Ai cumparat itemul!"));
        });
        ctx.get().setPacketHandled(true);
    }
}
