package com.phonemod.network.packet;

import com.phonemod.data.OlxListing;
import com.phonemod.data.PhoneMessage;
import com.phonemod.data.PhoneSavedData;
import com.phonemod.network.NetworkHandler;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class RequestDataPacket {
    private final String type; // "messages", "olx" sau "players"

    public RequestDataPacket(String type) {
        this.type = type;
    }

    public static void encode(RequestDataPacket msg, FriendlyByteBuf buf) {
        buf.writeUtf(msg.type);
    }

    public static RequestDataPacket decode(FriendlyByteBuf buf) {
        return new RequestDataPacket(buf.readUtf());
    }

    public static void handle(RequestDataPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            PhoneSavedData data = PhoneSavedData.get(player.serverLevel());
            CompoundTag tag = new CompoundTag();
            tag.putString("type", msg.type);

            if (msg.type.equals("messages")) {
                ListTag list = new ListTag();
                for (PhoneMessage m : data.getInbox(player.getUUID())) list.add(m.save());
                tag.put("messages", list);
            } else if (msg.type.equals("olx")) {
                ListTag list = new ListTag();
                for (OlxListing l : data.getListings()) list.add(l.save());
                tag.put("listings", list);
            } else if (msg.type.equals("players")) {
                ListTag list = new ListTag();
                for (ServerPlayer p : player.getServer().getPlayerList().getPlayers()) {
                    if (p != player) {
                        list.add(StringTag.valueOf(p.getGameProfile().getName()));
                    }
                }
                tag.put("players", list);
            }

            NetworkHandler.CHANNEL.sendTo(new SyncDataPacket(tag), player.connection.connection, NetworkDirection.PLAY_TO_CLIENT);
        });
        ctx.get().setPacketHandled(true);
    }
}
