package com.phonemod.data;

import net.minecraft.nbt.CompoundTag;

import java.util.UUID;

public class PhoneMessage {
    public UUID fromUUID;
    public String fromName;
    public String text;
    public long time;

    public PhoneMessage(UUID fromUUID, String fromName, String text, long time) {
        this.fromUUID = fromUUID;
        this.fromName = fromName;
        this.text = text;
        this.time = time;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putUUID("from", fromUUID);
        tag.putString("fromName", fromName);
        tag.putString("text", text);
        tag.putLong("time", time);
        return tag;
    }

    public static PhoneMessage load(CompoundTag tag) {
        return new PhoneMessage(tag.getUUID("from"), tag.getString("fromName"), tag.getString("text"), tag.getLong("time"));
    }
}
