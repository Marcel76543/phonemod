package com.phonemod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

public class OlxListing {
    public int id;
    public UUID sellerUUID;
    public String sellerName;
    public ItemStack stack;
    public int price;
    public String description;

    public OlxListing(int id, UUID sellerUUID, String sellerName, ItemStack stack, int price, String description) {
        this.id = id;
        this.sellerUUID = sellerUUID;
        this.sellerName = sellerName;
        this.stack = stack;
        this.price = price;
        this.description = description;
    }

    public CompoundTag save() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("id", id);
        tag.putUUID("seller", sellerUUID);
        tag.putString("sellerName", sellerName);
        tag.put("stack", stack.save(new CompoundTag()));
        tag.putInt("price", price);
        tag.putString("desc", description);
        return tag;
    }

    public static OlxListing load(CompoundTag tag) {
        return new OlxListing(
                tag.getInt("id"),
                tag.getUUID("seller"),
                tag.getString("sellerName"),
                ItemStack.of(tag.getCompound("stack")),
                tag.getInt("price"),
                tag.getString("desc")
        );
    }
}
