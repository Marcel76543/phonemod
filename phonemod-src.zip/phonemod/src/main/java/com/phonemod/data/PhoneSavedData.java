package com.phonemod.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class PhoneSavedData extends SavedData {
    public static final String DATA_NAME = "phonemod_data";

    private final Map<UUID, List<PhoneMessage>> inbox = new HashMap<>();
    private final List<OlxListing> listings = new ArrayList<>();
    private int nextListingId = 1;

    public static PhoneSavedData get(ServerLevel level) {
        return level.getServer().overworld().getDataStorage().computeIfAbsent(
                PhoneSavedData::load, PhoneSavedData::new, DATA_NAME);
    }

    public List<PhoneMessage> getInbox(UUID player) {
        return inbox.computeIfAbsent(player, k -> new ArrayList<>());
    }

    public void addMessage(UUID to, PhoneMessage message) {
        getInbox(to).add(message);
        setDirty();
    }

    public List<OlxListing> getListings() {
        return listings;
    }

    public void addListing(OlxListing listing) {
        listing.id = nextListingId++;
        listings.add(listing);
        setDirty();
    }

    public OlxListing removeListing(int id) {
        Iterator<OlxListing> it = listings.iterator();
        while (it.hasNext()) {
            OlxListing l = it.next();
            if (l.id == id) {
                it.remove();
                setDirty();
                return l;
            }
        }
        return null;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag inboxList = new ListTag();
        for (Map.Entry<UUID, List<PhoneMessage>> entry : inbox.entrySet()) {
            CompoundTag entryTag = new CompoundTag();
            entryTag.putUUID("player", entry.getKey());
            ListTag msgs = new ListTag();
            for (PhoneMessage m : entry.getValue()) msgs.add(m.save());
            entryTag.put("messages", msgs);
            inboxList.add(entryTag);
        }
        tag.put("inbox", inboxList);

        ListTag listingsList = new ListTag();
        for (OlxListing l : listings) listingsList.add(l.save());
        tag.put("listings", listingsList);
        tag.putInt("nextId", nextListingId);
        return tag;
    }

    public static PhoneSavedData load(CompoundTag tag) {
        PhoneSavedData data = new PhoneSavedData();
        ListTag inboxList = tag.getList("inbox", 10);
        for (int i = 0; i < inboxList.size(); i++) {
            CompoundTag entryTag = inboxList.getCompound(i);
            UUID player = entryTag.getUUID("player");
            ListTag msgs = entryTag.getList("messages", 10);
            List<PhoneMessage> list = new ArrayList<>();
            for (int j = 0; j < msgs.size(); j++) list.add(PhoneMessage.load(msgs.getCompound(j)));
            data.inbox.put(player, list);
        }
        ListTag listingsList = tag.getList("listings", 10);
        for (int i = 0; i < listingsList.size(); i++) data.listings.add(OlxListing.load(listingsList.getCompound(i)));
        data.nextListingId = tag.getInt("nextId");
        if (data.nextListingId == 0) data.nextListingId = 1;
        return data;
    }
}
