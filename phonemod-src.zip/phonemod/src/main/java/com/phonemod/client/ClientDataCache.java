package com.phonemod.client;

import com.phonemod.data.OlxListing;
import com.phonemod.data.PhoneMessage;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;

import java.util.ArrayList;
import java.util.List;

public class ClientDataCache {
    public static List<PhoneMessage> messages = new ArrayList<>();
    public static List<OlxListing> listings = new ArrayList<>();
    public static List<String> onlinePlayers = new ArrayList<>();

    public static void receive(CompoundTag tag) {
        String type = tag.getString("type");
        if (type.equals("messages")) {
            messages.clear();
            ListTag list = tag.getList("messages", 10);
            for (int i = 0; i < list.size(); i++) messages.add(PhoneMessage.load(list.getCompound(i)));
        } else if (type.equals("olx")) {
            listings.clear();
            ListTag list = tag.getList("listings", 10);
            for (int i = 0; i < list.size(); i++) listings.add(OlxListing.load(list.getCompound(i)));
        } else if (type.equals("players")) {
            onlinePlayers.clear();
            ListTag list = tag.getList("players", 8);
            for (int i = 0; i < list.size(); i++) onlinePlayers.add(list.getString(i));
        }
    }
}
