package com.phonemod.client;

import com.phonemod.client.gui.PhoneScreen;
import net.minecraft.client.Minecraft;

public class ClientHandler {
    public static void openPhone() {
        Minecraft.getInstance().setScreen(new PhoneScreen());
    }
}
