package com.phonemod.client.gui;

import com.phonemod.client.ClientDataCache;
import com.phonemod.data.OlxListing;
import com.phonemod.network.NetworkHandler;
import com.phonemod.network.packet.AddListingPacket;
import com.phonemod.network.packet.BuyListingPacket;
import com.phonemod.network.packet.RequestDataPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class OlxScreen extends PhoneScreenBase {
    private EditBox priceBox;
    private EditBox descBox;

    public OlxScreen() {
        super(Component.literal("OLX"));
    }

    @Override
    protected void init() {
        super.init();

        priceBox = new EditBox(font, phoneX + 10, phoneY + 22, 50, 16, Component.literal("Pret"));
        priceBox.setHint(Component.literal("Pret"));
        addRenderableWidget(priceBox);

        descBox = new EditBox(font, phoneX + 64, phoneY + 22, WIDTH - 74, 16, Component.literal("Descriere"));
        descBox.setHint(Component.literal("Descriere"));
        addRenderableWidget(descBox);

        addRenderableWidget(Button.builder(Component.literal("Publica (itemul din mana)"), b -> {
            try {
                int price = Integer.parseInt(priceBox.getValue().trim());
                NetworkHandler.CHANNEL.sendToServer(new AddListingPacket(price, descBox.getValue().trim()));
                priceBox.setValue("");
                descBox.setValue("");
            } catch (NumberFormatException ignored) {
            }
        }).bounds(phoneX + 10, phoneY + 42, WIDTH - 20, 18).build());

        addRenderableWidget(Button.builder(Component.literal("Refresh"), b ->
                NetworkHandler.CHANNEL.sendToServer(new RequestDataPacket("olx")))
                .bounds(phoneX + 10, phoneY + 64, 60, 16).build());

        addRenderableWidget(Button.builder(Component.literal("< Inapoi"), b -> minecraft.setScreen(new PhoneScreen()))
                .bounds(phoneX + 10, phoneY + HEIGHT - 28, WIDTH - 20, 18).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        List<OlxListing> listings = ClientDataCache.listings;
        int y = phoneY + 86;
        if (listings.isEmpty()) {
            graphics.drawString(font, "Niciun anunt momentan.", phoneX + 10, y, 0x999999, false);
            return;
        }
        int max = Math.min(listings.size(), 5);
        for (int i = 0; i < max; i++) {
            OlxListing l = listings.get(i);
            int fy = y + i * 24;
            String name = l.stack.getHoverName().getString();
            String line = l.sellerName + ": " + l.stack.getCount() + "x " + name;
            if (line.length() > 20) line = line.substring(0, 20) + "..";
            graphics.drawString(font, line, phoneX + 10, fy, 0xFFFFFF, false);
            graphics.drawString(font, l.description, phoneX + 10, fy + 10, 0x999999, false);

            graphics.fill(phoneX + WIDTH - 90, fy, phoneX + WIDTH - 10, fy + 16, 0xFF3A5F3A);
            graphics.drawCenteredString(font, l.price + " emeralds", phoneX + WIDTH - 50, fy + 4, 0xFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<OlxListing> listings = ClientDataCache.listings;
        int y = phoneY + 86;
        int max = Math.min(listings.size(), 5);
        for (int i = 0; i < max; i++) {
            int fy = y + i * 24;
            if (mouseX >= phoneX + WIDTH - 90 && mouseX <= phoneX + WIDTH - 10 && mouseY >= fy && mouseY <= fy + 16) {
                NetworkHandler.CHANNEL.sendToServer(new BuyListingPacket(listings.get(i).id));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
