package com.phonemod.client.gui;

import com.phonemod.client.ClientDataCache;
import com.phonemod.data.PhoneMessage;
import com.phonemod.network.NetworkHandler;
import com.phonemod.network.packet.SendMessagePacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class MessagesScreen extends PhoneScreenBase {
    private EditBox toBox;
    private EditBox textBox;

    public MessagesScreen() {
        super(Component.literal("Mesaje"));
    }

    @Override
    protected void init() {
        super.init();

        toBox = new EditBox(font, phoneX + 10, phoneY + 24, WIDTH - 20, 16, Component.literal("Catre"));
        toBox.setHint(Component.literal("Nume jucator"));
        addRenderableWidget(toBox);

        textBox = new EditBox(font, phoneX + 10, phoneY + 44, WIDTH - 20, 16, Component.literal("Mesaj"));
        textBox.setMaxLength(200);
        textBox.setHint(Component.literal("Scrie un mesaj..."));
        addRenderableWidget(textBox);

        addRenderableWidget(Button.builder(Component.literal("Trimite"), b -> {
            if (!toBox.getValue().isBlank() && !textBox.getValue().isBlank()) {
                NetworkHandler.CHANNEL.sendToServer(new SendMessagePacket(toBox.getValue().trim(), textBox.getValue().trim()));
                textBox.setValue("");
            }
        }).bounds(phoneX + 10, phoneY + 64, WIDTH - 20, 18).build());

        addRenderableWidget(Button.builder(Component.literal("< Inapoi"), b -> minecraft.setScreen(new PhoneScreen()))
                .bounds(phoneX + 10, phoneY + HEIGHT - 28, WIDTH - 20, 18).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        int y = phoneY + 90;
        graphics.drawString(font, "Inbox:", phoneX + 10, y, 0xAAAAAA, false);
        y += 12;
        List<PhoneMessage> msgs = ClientDataCache.messages;
        int start = Math.max(0, msgs.size() - 6);
        for (int i = start; i < msgs.size(); i++) {
            PhoneMessage m = msgs.get(i);
            String line = "§e" + m.fromName + "§r: " + m.text;
            if (line.length() > 30) line = line.substring(0, 30) + "...";
            graphics.drawString(font, line, phoneX + 10, y, 0xFFFFFF, false);
            y += 11;
        }
        if (msgs.isEmpty()) {
            graphics.drawString(font, "Niciun mesaj.", phoneX + 10, y, 0x999999, false);
        }
    }
}
