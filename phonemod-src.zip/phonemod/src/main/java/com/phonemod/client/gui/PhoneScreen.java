package com.phonemod.client.gui;

import com.phonemod.network.NetworkHandler;
import com.phonemod.network.packet.RequestDataPacket;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class PhoneScreen extends PhoneScreenBase {
    public PhoneScreen() {
        super(Component.literal("Telefon"));
    }

    @Override
    protected void init() {
        super.init();
        int cx = phoneX + 10;
        int cy = phoneY + 24;

        addRenderableWidget(Button.builder(Component.literal("Mesaje"), b -> {
            NetworkHandler.CHANNEL.sendToServer(new RequestDataPacket("messages"));
            minecraft.setScreen(new MessagesScreen());
        }).bounds(cx, cy, WIDTH - 20, 20).build());

        addRenderableWidget(Button.builder(Component.literal("OLX"), b -> {
            NetworkHandler.CHANNEL.sendToServer(new RequestDataPacket("olx"));
            minecraft.setScreen(new OlxScreen());
        }).bounds(cx, cy + 28, WIDTH - 20, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Contacte"), b -> {
            NetworkHandler.CHANNEL.sendToServer(new RequestDataPacket("players"));
            minecraft.setScreen(new ContactsScreen());
        }).bounds(cx, cy + 56, WIDTH - 20, 20).build());

        addRenderableWidget(Button.builder(Component.literal("Inchide"), b -> onClose())
                .bounds(cx, phoneY + HEIGHT - 28, WIDTH - 20, 20).build());
    }
}
