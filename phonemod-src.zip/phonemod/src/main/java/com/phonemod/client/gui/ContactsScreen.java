package com.phonemod.client.gui;

import com.phonemod.client.ClientDataCache;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class ContactsScreen extends PhoneScreenBase {
    public ContactsScreen() {
        super(Component.literal("Contacte"));
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(Button.builder(Component.literal("< Inapoi"), b -> minecraft.setScreen(new PhoneScreen()))
                .bounds(phoneX + 10, phoneY + HEIGHT - 28, WIDTH - 20, 18).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        super.render(graphics, mouseX, mouseY, partialTick);
        int y = phoneY + 24;
        graphics.drawString(font, "Jucatori online:", phoneX + 10, y, 0xAAAAAA, false);
        y += 12;
        for (String name : ClientDataCache.onlinePlayers) {
            graphics.drawString(font, "- " + name, phoneX + 14, y, 0xFFFFFF, false);
            y += 11;
        }
        if (ClientDataCache.onlinePlayers.isEmpty()) {
            graphics.drawString(font, "Niciun alt jucator online.", phoneX + 14, y, 0x999999, false);
        }
    }
}
