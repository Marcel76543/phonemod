package com.phonemod.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public abstract class PhoneScreenBase extends Screen {
    public static final int WIDTH = 200;
    public static final int HEIGHT = 220;
    protected int phoneX, phoneY;

    protected PhoneScreenBase(Component title) {
        super(title);
    }

    @Override
    protected void init() {
        phoneX = (width - WIDTH) / 2;
        phoneY = (height - HEIGHT) / 2;
    }

    protected void renderFrame(GuiGraphics graphics, String screenTitle) {
        graphics.fill(phoneX, phoneY, phoneX + WIDTH, phoneY + HEIGHT, 0xFF1A1A1A);
        graphics.fill(phoneX + 2, phoneY + 2, phoneX + WIDTH - 2, phoneY + HEIGHT - 2, 0xFF2E2E2E);
        graphics.drawCenteredString(font, screenTitle, phoneX + WIDTH / 2, phoneY + 6, 0xFFFFFF);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        renderFrame(graphics, title.getString());
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
