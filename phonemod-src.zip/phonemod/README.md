# Phone Mod (Forge 1.20.1)

Mod Minecraft Forge pentru 1.20.1 care adauga un item **Telefon**. Click-dreapta cu telefonul in mana deschide un ecran cu 3 aplicatii:

- **Mesaje** — trimiti un mesaj text catre orice jucator online (dupa nume). Mesajele se salveaza in inbox-ul destinatarului chiar daca nu e online in acel moment.
- **OLX** — postezi la vanzare itemul pe care il tii in mana, cu un pret in smaralde si o descriere. Alti jucatori pot cumpara direct din telefon (platesc automat cu smaralde din inventar).
- **Contacte** — lista jucatorilor online pe server.

Datele (mesaje + anunturi) se salveaza pe server, persistent, in world save.

---

## 1. Ce contine acest folder

Doar codul sursa (`src/main/java`, `src/main/resources`) + `gradle.properties`. Nu contine `build.gradle`, `settings.gradle` sau gradle wrapper-ul, pentru ca acelea vin din MDK-ul oficial Forge (nu pot fi generate fara acces la internet in acest mediu).

## 2. Cum construiesti mod-ul local

### Pas 1 — Instaleaza Java 17 (JDK)
Descarca si instaleaza [Adoptium Temurin JDK 17](https://adoptium.net/).

### Pas 2 — Descarca MDK-ul oficial Forge pentru 1.20.1
Mergi pe https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html , alege o versiune recomandata (ex: `47.2.20`) si descarca **"Mdk"** (zip).

### Pas 3 — Combina fisierele
1. Dezarhiveaza MDK-ul intr-un folder nou, ex `phonemod-project/`.
2. Sterge folderul `src/main/java/com/example/examplemod` si `src/main/resources` din MDK (contin mod-ul exemplu).
3. Copiaza peste ele folderele `src/main/java` si `src/main/resources` din acest proiect.
4. Inlocuieste `gradle.properties` din MDK cu `gradle.properties` din acest proiect (sau editeaza-l manual cu valorile de mai sus).
5. `build.gradle` si `settings.gradle` raman cele din MDK — nu trebuie schimbate, citesc automat valorile din `gradle.properties`.

Structura finala trebuie sa arate asa:
```
phonemod-project/
  build.gradle
  settings.gradle
  gradle.properties      <- al tau
  gradlew, gradlew.bat
  gradle/
  src/main/java/com/phonemod/...     <- al tau
  src/main/resources/...             <- al tau
```

### Pas 4 — Build
In terminal, in folderul proiectului:

```bash
# Linux/Mac
./gradlew build

# Windows
gradlew.bat build
```

Prima rulare dureaza mai mult (descarca Forge + dependinte). Jar-ul rezultat apare in `build/libs/phonemod-1.0.0.jar`.

### Pas 5 — Testeaza in joc
```bash
./gradlew runClient
```
Asta porneste un client Minecraft cu mod-ul incarcat direct din cod (fara sa mai faci build de jar). Cauta itemul "Telefon" in tab-ul creative **Tools and Utilities**, sau da-ti-l cu:
```
/give @s phonemod:phone
```

Pentru a testa Mesaje/OLX intre 2 jucatori ai nevoie de 2 clienti sau un client + un server local (`./gradlew runServer` apoi te conectezi cu clientul normal de Minecraft cu mod-ul instalat in `.minecraft/mods`).

---

## 3. Cum il urci pe GitHub

In folderul `phonemod-project/` (cel cu tot, inclusiv build.gradle-ul din MDK):

```bash
git init
git add .
git commit -m "Initial commit - Phone Mod"
```

Adauga un `.gitignore` (daca MDK-ul nu are deja unul) cu:
```
build/
.gradle/
.idea/
*.iml
out/
run/
eclipse/
bin/
```

Creeaza un repo nou pe https://github.com/new (fara README, fara .gitignore — le ai deja), apoi:

```bash
git remote add origin https://github.com/NUMELE_TAU/phonemod.git
git branch -M main
git push -u origin main
```

Daca iti cere autentificare, GitHub nu mai accepta parola direct — foloseste un **Personal Access Token** (Settings → Developer settings → Personal access tokens) in loc de parola, sau autentifica-te cu `gh auth login` daca ai GitHub CLI instalat.

---

## 4. Idei de extindere

- Craft recipe pentru telefon (acum se ia doar din creative/comanda).
- Notificare cu sunet cand primesti un mesaj nou.
- Categorii/cautare in OLX.
- Aplicatie "Harta" care arata coordonatele jucatorilor din contacte.
